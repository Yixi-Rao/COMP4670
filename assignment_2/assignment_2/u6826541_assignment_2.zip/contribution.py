def contribution_statement():
    # TODO Add contribution / reference / collaboration statement as a string.
    statement = "I don't have any group members or any collaboration has in completing the assignment. I finished it by myself"

    return statement