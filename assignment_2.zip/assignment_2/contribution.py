def contribution_statement():
    # TODO Add contribution / reference / collaboration statement as a string.
    statement = ""

    return statement